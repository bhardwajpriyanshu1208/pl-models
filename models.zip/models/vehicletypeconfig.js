const mongoose = require("mongoose");

const vehicleConfigurationSchema = mongoose.Schema(
  {
    company: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "company",
      },
      vehicleType: {
        type: String,
        // unique: true,
        // required: true,
      },
      description: {
        type: String,
      },
      weight: {
        type: Number,
        // required: true,
      },
      weight_uom: {
          type: String,
          // required: true,
      },
      volume: {
        type: Number,
        // required: true,
      },
      volume_uom: {
          type: String,
          // required: true,

      },
      quantity: {
        type:  Number,
        // required: true,
      },
      quantity_uom: {
          type: String,
          // required: true,
      },
      length: {
        type: Number,
        // required: true,
    },
    width: {
        type: Number,
        // required: true,
    },
    height: {
        type: Number,
        // required: true,
    },
    dim_uom: {
        type: String,
        // required: true,
    },
    },
    {
        timestamps: true,
    }
    );

const VehicleConfiguration = mongoose.model("vehicleConfiguration", vehicleConfigurationSchema);

module.exports = VehicleConfiguration;
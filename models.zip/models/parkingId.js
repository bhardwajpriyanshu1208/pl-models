const mongoose = require("mongoose");

const parkingIdSchema = new mongoose.Schema(
  {
    parkingId: {
      type: String,
      required: true,
    },
    zoneId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "parkingZone",
    },
    vehicleAlloted: {
      type: Boolean,
      default: false,
    },
    vehicle: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Trip",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("parkingId", parkingIdSchema);

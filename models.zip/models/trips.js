const mongoose = require("mongoose");

const tripSchema = mongoose.Schema({
  reportingID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "reportedVehicle",
  },
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "company",
  },
  location: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  tripID: {
    type: Number,
  },
  tripType: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "TripType",
  },
  modeOfTransport: {
    type: String,
  },
  plannedWeight: {
    type: Number,
  },
  weightUnit: {
    type: String,
  },
  plannedVolume: {
    type: Number,
  },
  volumeUnit: {
    type: String,
  },
  plannedQuantity: {
    type: Number,
  },
  quantityUnit: {
    type: String,
  },
  startTime: Date,
  endTime: Date,
  totalDistance: String,
  totalDistanceUnit: { type: String, default: "Km" },
  totalDuration: String,
  totalDurationUnit: { type: String, default: "Hr" },
  departureLocation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  arrivalLocation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  noOfPickups: String,
  noOfDeliveries: String,
  stages: [
    {
      stageId: String,
      source: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
      destination: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
      arrival: Date,
      departure: Date,
      stageType: String, // Pickup , Delivery , Cross Dock
      distance: Number,
      distanceUnit: String,
      duration: Number,
    },
  ],
  items: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Item",
    },
  ],
  actualItems: [
    {
      materialCode: {
        type: String,
      },
      materialDescription: {
        type: String,
      },
      quantity: {
        type: Number,
      },
      quantityUOM: {
        type: String,
      },
      weight: {
        type: Number,
      },
      weightUOM: {
        type: String,
      },
      isLoaded: {
        type: Boolean,
      },
      itemNo: {
        type: String,
      },
      itemKey: {
        type: String,
      },
      itemCategory: {
        type: String,
      },
      itemParentKey: {
        type: String,
      },
    },
  ],
  status: {
    type: String,
    enum: [
      "Trip Planned",
      "Gate Pass Created",
      "Gate In",
      "Tare Weight Measured",
      "Loading Started",
      "Loading Completed",
      "Unloading Started",
      "Unloading Completed",
      "Gross Weight Measured",
      "Gate Out",
      "Gate Out Denied",
    ],
  },
  gatePassID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "gatepass",
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  systemID: {
    type: String,
  },
  actualWeight: {
    type: Number,
  },
  actualWeight_uom: {
    type: String,
  },
  actualQuantity: {
    type: Number,
  },
  actualQuantity_uom: {
    type: String,
  },
  actualVolume: {
    type: Number,
  },
  actualVolume_uom: {
    type: String,
  },
  capacity: {
    type: String,
  },
  odoMeterReading: String,
  fuelLevel: String,
  notes: String,
  actualGateInTime: {
    type: Date,
  },
  vehiclePosition: String,
  gateinBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  tareWeight: {
    type: Number,
  },
  tareWeightUnit: {
    type: String,
  },
  tareWeightCapturedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  loadingStartTime: {
    type: Date,
  },
  loadingStartedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  unloadingStartTime: {
    type: Date,
  },
  unloadingStartedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  loadingCompleteTime: {
    type: Date,
  },
  unloadingCompleteTime: {
    type: Date,
  },
  grossWeight: {
    type: Number,
  },
  grossWeightUnit: {
    type: String,
  },
  grossWeightCapturedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  gateOutTime: {
    type: Date,
  },
  gateOutGateNo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "GateNo",
  },
  gateOutCheklist: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "checklist",
  },
  gateOutLocation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  gateOutBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  lifeCycleStatus: {
    type: String,
    enum: ["Not Started", "In Process", "Completed", "Cancelled"],
  },
  cancelReason: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "reason",
  },
  checkOutChecklist: [
    {
      class: String,
      items: [
        {
          name: String,
          status: String,
          comment: String,
        },
      ],
    },
  ],
});

const Trip = mongoose.model("Trip", tripSchema);

module.exports = Trip;

const mongoose = require("mongoose");

const gatePassSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    reason: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "reason",
    },
    reportingID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "reportingID",
    },
    tripId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Trip",
    },
    vehicleNumber: {
      type: String,
    },
    gateNumber: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "GateNo",
    },
    plannedGateInTime: {
      type: Date,
    },
    parkingZone: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "parkingZone",
    },
    parkingID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "parkingId",
    },
    dockID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Dock",
    },
    gatePassCreatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    checkinChecklist: [
      {
        class: String,
        items: [
          {
            name: String,
            status: String,
            comment: String,
          },
        ],
      },
    ],
    gatePassIssuedOn: {
      type: Date,
    },
    status: {
      type: String,
      enum: ["New", "Denied", "Cancelled", "Completed"],
    },
  },
  {
    timestamp: true,
  }
);

const Gatepass = mongoose.model("gatepass", gatePassSchema);

module.exports = Gatepass;

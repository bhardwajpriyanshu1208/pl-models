const mongoose = require("mongoose");

const reportedVehicleSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    location: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "location",
    },
    reportedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    resource: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "resource",
    },
    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "driver",
    },
    qrCode: String,
    reportingDate: {
      type: Date,
      required: true,
    },
    vehicleNumber: {
      type: String,
      required: true,
    },
    driverName: {
      type: String,
    },
    driverMobile: {
      type: String,
    },
    driverLicense: {
      type: String,
    },
    carrierName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "businessPartner",
      // required: true,
    },
    processType: {
      type: String,
      required: true,
    },
    purpose: {
      type: String,
      required: true,
    },
    // destinationLocation: {
    //   type: String,
    // },
    destinationLocation: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
    ],
    resourceType: {
      type: mongoose.Schema.Types.ObjectId,
      // required: true,
      ref: "vehicleConfiguration",
    },
    status: {
      type: String,
      enum: [
        "Ready",
        "Blocked",
        "On Hold",
        "In Progress",
        "Gate Out",
        "Cancelled",
      ],
    },
    reasonCode: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "reason",
      required: false,
    },
    tripNumber: String,
    tripId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Trip",
    },
  },
  {
    timestamps: true,
  }
);

const ReportedVehicle = mongoose.model(
  "reportedVehicle",
  reportedVehicleSchema
);

module.exports = ReportedVehicle;

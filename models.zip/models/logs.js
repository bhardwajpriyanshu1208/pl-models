const mongoose = require("mongoose");

const logSchema = mongoose.Schema({
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "company",
  },
  location: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  url: String,
  payload: String,
  method: String,
  response: String,
  statusCode: Number,
});

const Logs = mongoose.model("log", logSchema);

module.exports = Logs;

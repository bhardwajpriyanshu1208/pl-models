const mongoose = require("mongoose");

const itemsSchema = new mongoose.Schema({
  customerName: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "businessPartner",
  },
  source: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  destination: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "location",
  },
  materialCode: {
    type: String,
  },
  materialDescription: {
    type: String,
  },
  quantity: {
    type: Number,
  },
  quantityUOM: {
    type: String,
  },
  weight: {
    type: Number,
  },
  weightUOM: {
    type: String,
  },
  volume: {
    type: Number,
  },
  volumeUOM: {
    type: String,
  },
  indentID: {
    type: String,
  },
  indentType: {
    type: String,
  },
  deliveryTime: {
    type: String,
  },
  tripId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Trip",
  },
  itemNo: {
    type: String,
  },
  itemKey: {
    type: String,
  },
  itemCategory: {
    type: String,
  },
  itemParentKey: {
    type: String,
  },
});

const Items = mongoose.model("Item", itemsSchema);

module.exports = Items;

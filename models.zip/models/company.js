const mongoose = require("mongoose");

const companySchema = mongoose.Schema({
  companyName: {
    type: String,
  },

  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
  },
  companyId: {
    type: String,
  },

  permanentAddress: {
    street: String,
    houseNo: String,
    country: { type: String },
    state: { type: String },
    city: { type: String },
    postalCode: {
      type: String,
    },
    timeZone: String,
  },

  domain: {
    type: String,
  },

  contactEmail: {
    type: String,
  },

  contactNo: {
    type: String,
  },
  apiUsage: {
    type: Number,
    default: "0",
  },

  dbUsage: {
    type: Number,
    default: "0",
  },

  companyLogo: {
    type: String,
  },

  checkinChecklist: [
    {
      class: String,
      checklists: [
        {
          name: String,
          status: String,
          image: String,
        },
      ],
    },
  ],

  checkoutChecklist: [
    {
      class: String,
      checkLists: [
        {
          name: String,
          status: Boolean,
          image: String,
        },
      ],
    },
  ],

  // location: {
  //   type: String,
  // },
});

const Company = mongoose.model("company", companySchema);

module.exports = Company;

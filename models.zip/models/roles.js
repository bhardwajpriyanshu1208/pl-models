const mongoose = require("mongoose");

const rolesSchema = mongoose.Schema({
  name: {
    type: String,
  },
  description: {
    type: String,
  },
  permissions: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "permissions",
    },
  ],
  badge: {
    type: Number,
  },
  isGlobal: {
    type: Boolean,
  },
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "company",
  },
});

const roles = mongoose.model("role", rolesSchema);

module.exports = roles;

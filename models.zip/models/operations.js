const mongoose = require("mongoose");

const operationsSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },

    // reporting starts
    location: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "location",
    },
    resource: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "resource",
    },
    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "driver",
    },
    qrCode: String,
    reportingDate: {
      type: Date,
    },
    reportingGate: {
      type: String,
    },
    vehicleNumber: {
      type: String,
    },
    driverName: {
      type: String,
    },
    driverMobile: {
      type: String,
    },
    driverLicense: {
      type: String,
    },
    carrierName: {
      type: mongoose.Schema.Types.ObjectId,
    },
    processType: {
      type: String,
    },
    purpose: {
      type: String,
    },
    destinationLocation: {
      type: String,
    },

    reportedBy: {
      type: String,
      // in future type will be changed to mongoose.Schema.Types.ObjectId of user
    },
    gateNumber: {
      type: String,
    },
    gateInTime: {
      type: Date,
    },
    gatePassIssuedBy: {
      type: String,
    },
    gatePassIssuedOn: {
      type: Date,
    },
    gatePassContactNo: {
      type: String,
    },
    activityStatus: {
      type: String,
      enum: ["Ready", "Blocked", "Cancelled", "Hold"],
    },
    blockReason: {
      type: String,
    },
    status: {
      type: String,
      enum: [
        "Reported",
        "Trip Planned",
        "Gate in Planned",
        "GateIn",
        "TareWeight",
        "Parked",
        "Docking",
        "Docking Complete",
        "GrossWeight",
        "Gateout",
      ],
    },

    nextStep: {
      type: String,
      enum: [
        "report",
        "plan",
        "gatePass",
        "gateIn",
        "tareWeight",
        "dock",
        "grossWeight",
        "gateOut",
      ],
    },
    resourceType: {
      type: mongoose.Schema.Types.ObjectId,
    },
    sequenceNumber: {
      type: Number,
      // config
    },
    poNumber: {
      type: String,
    },
    // reporting ends
    // planning starts
    tripNumber: {
      type: String,
    },
    tripStartDate: {
      type: Date,
    },
    source: String,
    destination: String,
    numberOfPickups: Number,
    numberOfDeliveries: Number,
    totalDistance: Number,
    totalDistanceUnit: String,
    totalDuration: Number, // convert to minutes
    plannedWeight: {
      type: Number,
      // to be asked
    },
    weightUnit: {
      type: String,
    },
    plannedVolume: Number,
    volumeUnit: {
      type: String,
    },
    plannedQuantity: Number,
    quantityUnit: String,
    routes: [{ type: mongoose.Schema.Types.ObjectId, ref: "route" }],
    items: [{ type: mongoose.Schema.Types.ObjectId, ref: "item" }],

    indentNumber: {
      type: String,
    },
    indentType: {
      type: String,
    },
    expectedLoadingTime: {
      type: Date,
    },
    asnNumber: {
      type: String,
    },
    poDate: {
      type: Date,
    },
    loadType: {
      type: String,
    },
    planningDate: {
      type: Date,
    },
    inboundDeliveryNo: String,
    supplierName: String,
    /// planning ends
    /// create gate pass
    checkInGate: String,
    plannedCheckInTime: {
      type: Date,
    },
    parkingID: String,
    dockID: String,
    // plannning ends
    // checkin starts
    checkinChecklist: [
      {
        class: String,
        checklists: [
          {
            name: String,
            status: String,
            comment: String,
          },
        ],
      },
    ],
    actualCheckinTime: Date,
    checkedInBy: {
      type: String,
      // in future type will be changed to mongoose.Schema.Types.ObjectId of user
    },
    //// checkin ends

    ///// capture tare weight
    tareWeight: Number,
    tareWeightUnit: String,
    //// loading/ unloading starts
    dockStartTime: Date,
    /// loading completion
    dockEndTime: Date,
    actualQuantity: Number,
    actualWeight: Number,
    actualVolume: Number,

    /// capture gross weight

    grossWeight: Number,
    cargoWeight: Number,

    weighmentSlipNumber: {
      type: String,
    },

    // checkout starts
    checkoutChecklist: [
      {
        class: String,
        checkLists: [
          {
            name: String,
            status: String,
            comment: String,
          },
        ],
      },
    ],

    checkOutDate: {
      type: Date,
    },
    checkedOutBy: {
      type: String,
      // in future type will be changed to mongoose.Schema.Types.ObjectId of user
    },
    checkOutGate: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

const operations = mongoose.model("operation", operationsSchema);

module.exports = operations;

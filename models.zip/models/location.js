const mongoose = require("mongoose");

const locationSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    locationId: {
      type: String,
      required: true,
    },

    locationDescription: {
      required: true,
      type: String,
    },

    locationType: {
      type: String,
    },

    contactPerson: {
      required: true,
      type: String,
    },
    email: String,
    mobileNo: {
      required: true,
      type: String,
    },
    permanentAddress: {
      street: String,
      houseNo: String,
      country: { type: String, required: true },
      state: { type: String, required: true },
      city: { type: String, required: true },
      postalCode: {
        type: String,
        required: true,
      },
      timeZone: String,
    },

    activeStatus: {
      // required: true,
      type: String,
    },

    inactiveReason: {
      type: String,
    },

    googlePlusCode: {
      type: String,
      required: true,
    },
    latitude: {
      type: String,
    },
    longitude: {
      type: String,
    },
    iataCode: {
      type: String,
    },
    unloCode: {
      type: String,
    },
    timeZone: {
      type: String,
      // required: true,
    },
    waitTime: {
      type: String,
      required: true,
    },
    languages: [String],
    verifyCheckout: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

const Location = mongoose.model("location", locationSchema);

module.exports = Location;

const mongoose = require("mongoose");
const checklistSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    process: String,
    activity: String,
    type: String,
    item: String,
    isGlobal: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    vehicleType: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "vehicleConfiguration",
    }],
    
    // vehicleType: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   // required: true,
    //   ref: "vehicleConfiguration",
    // },
  },
  {
    timestamps: true,
  }
);

const Checklist = mongoose.model("checklist", checklistSchema);

module.exports = Checklist;

const mongoose = require("mongoose");

const permissionsSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
});

const permissions = mongoose.model("permission", permissionsSchema);

module.exports = permissions;

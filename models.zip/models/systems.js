const mongoose = require("mongoose");

const systemSchema = mongoose.Schema({
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "company",
  },
  locations: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "location",
    },
  ],
  systemName: {
    type: String,
  },
  systemId: {
    type: String,
  },
  protocol: String,
  systemIP: {
    type: String,
  },
  systemPort: {
    type: String,
  },
  systemUserName: {
    type: String,
  },
  systemPassword: {
    type: String,
  },
  reportingEndPoint: {
    type: String,
  },
  summaryEndPoint: {
    type: String,
  },
});

const System = mongoose.model("system", systemSchema);

module.exports = System;

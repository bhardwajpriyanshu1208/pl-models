const mongoose = require("mongoose");

const driverSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    location: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
    ],
    name: {
      required: true,
      type: String,
    },
    driverImage: String,
    gender: {
      required: true,
      type: String,
      enum: ["Male", "Female", "Others"],
    },
    email: String,
    bloodGroup: {
      type: String,
      enum: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
    },
    countryCode: {
      type: String,
    },
    mobileNo: {
      required: true,
      type: String,
    },
    dob: {
      type: Date,
    },
    drivingLicenseNo: {
      required: true,
      type: String,
    },
    licenseType: {
      type: String,
      required: true,
    },
    licenseIssueDate: {
      type: Date,
      required: true,
    },
    licenseValidUpto: {
      type: Date,
      required: true,
    },
    insuranceDetails: {
      provider: String,
      amount: Number,
      validityStartDate: Date,
      validityEndDate: Date,
    },
    permanentAddress: {
      street: String,
      houseNo: String,
      country: { type: String, required: true },
      state: { type: String, required: true },
      city: { type: String, required: true },
      postalCode: {
        type: String,
        required: true,
      },
      timeZone: String,
    },
    communicationAddress: {
      isSame: { type: Boolean },
      street: String,
      houseNo: String,
      country: { type: String },
      state: { type: String },
      city: { type: String },
      postalCode: {
        type: String,
      },
      timeZone: String,
    },
    vendorName: String,
    dateOfJoining: Date,
    dateOfRelieving: Date,
    attachments: [
      {
        attachmentType: String,
        description: String,
        url: String,
        fileName: String,
      },
    ],
    isActive: { type: Boolean, default: true },
    isBlocked: { type: Boolean, default: false },
    blockingReason: String,

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

const Driver = mongoose.model("driver", driverSchema);

module.exports = Driver;

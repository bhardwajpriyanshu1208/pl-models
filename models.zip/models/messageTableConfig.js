const mongoose = require("mongoose");
const messageTableConfigSchema = new mongoose.Schema(
    {
      processID: {
        type: String,
        required: true,
      },
      messageNumber: {
        type: Number,
        required: true,
      },
      text: {
        type: String,
        required: true,
      },
      isGlobal: {
        type: Boolean,
        default: false,
      },
      company: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "company",
      },
      createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user",
      },
      reason: {
        type: mongoose.Schema.Types.ObjectId,
        // required: true,
        ref:"reason"
      },

    },
    { timestamps: true }
  );
  
  const MessageTableConfig = mongoose.model("messageTableConfig", messageTableConfigSchema);
  
  module.exports = MessageTableConfig;
  

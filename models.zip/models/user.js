const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    mobile: {
      type: String,
      required: true,
    },
    password: {
      type: String, // Priyanshu@123   --- hashvalue   // create new || update
      required: true,
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    role: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "role",
    },
    location: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
    ],
    country: String,
    state: String,
    city: String,
    image: String,

    selectedDateRange: {
      type: String,
      default: "All",
    },
    customDateRange: {
      start: Date,
      end: Date,
    },
    selectedLocations: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
    ],
    // isActive: {
    //   type: Boolean,
    //   default: true,
    // },
    activeStatus: {
      // required: true,
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

// hashing

userSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 12);
  }
  next();
});

const User = mongoose.model("user", userSchema);

module.exports = User;

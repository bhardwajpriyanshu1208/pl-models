const mongoose = require("mongoose");

const resourceSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    location: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "location",
      },
    ],
    resourceId: {
      required: true,
      type: String,
    },
    resourceDescription: {
      // required: true,
      type: String,
    },
    // resourceType: {
    //   required: true,
    //   type: String,
    //   enum: ["Truck", "Tank", "Crane", "Forklift", "Earth Mover"],
    // },

    resourceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "vehicleConfiguration",
      // required: true,
    },
    registrationCertificate: {
      required: true,
      type: String,
    },
    chassisNo: {
      required: true,
      type: String,
    },
    engineNo: {
      required: true,
      type: String,
    },
    monthAndYearOfManufacturing: {
      type: String,
      required: true,
    },
    dateOfRegistration: {
      type: Date,
    },
    registrationValidity: {
      type: Date,
    },
    fuelUsed: {
      type: String,
      enum: ["Petrol", "Diesel", "Electric", "CNG"],
    },
    makersClassification: {
      type: String,
      // required: true,
    },
    rtoLocation: {
      type: String,
      required: true,
    },
    insuranceVendor: {
      type: String,
      required: true,
    },
    insuranceAmount: {
      type: Number,
    },
    insuranceIssuedDate: {
      type: Date,
      required: true,
    },
    insuranceValidUpto: {
      type: Date,
      required: true,
    },
    permit: {
      type: String,
      // required: true,
    },
    nationalPermit: {
      type: String,
    },
    statePermit: {
      type: String,
    },
    npValidFromDate: {
      type: Date,
      required: true,
    },
    npValidToDate: {
      type: Date,
      required: true,
    },
    owner: {
      type: String,
    },
    responsiblePerson: {
      type: String,
      required: true,
    },
    emailId: {
      type: String,
      required: true,
    },
    mobileNo: {
      //  required: true,
      type: String,
    },
    driverName: {
      type: String,
    },

    // isActive:{
    //   type: String,
    //   enum: [
    //     "Active",
    //     "NotActive",
    //   ],
    // },
    isBlocked: {
      type: String,
      // enum: [
      //   "Blocked",
      //   "NotBlocked",
      // ],
    },
    activeStatus: {
      // required: true,
      type: String,
    },

    inactiveReason: {
      type: String,
    },

    blockingReason: {
      type: String,
      // enum: [
      //   "Permit expired",
      //   "RC expired",
      //   "Insurance expired",
      //   "Not fit",
      //   "PUC expired",
      // ],
    },
    capacity: {
      type: String,
      required: true,
    },
    weight: {
      type: String,
      // required: true,
    },
    weight_uom: {
      type: String,
      required: true,
    },
    volume: {
      type: Number,
      required: true,
    },
    volume_uom: {
      type: String,
      required: true,
    },
    quantity: {
      type: String,
      // required: true,
    },
    quantity_uom: {
      type: String,
      required: true,
    },
    length: {
      type: Number,
      required: true,
    },
    width: {
      type: Number,
      // required: true,
    },
    height: {
      type: Number,
      // required: true,
    },
    dim_uom: {
      type: String,
      required: true,
    },
    attachments: [
      {
        attachmentType: String,
        description: String,
        url: String,
        fileName: String,
      },
    ],

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },

    driverName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "driver",
    },

    carrierName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "businessPartner",
    },
  },
  {
    timestamps: true,
  }
);

const Resource = mongoose.model("resource", resourceSchema);

module.exports = Resource;

const mongoose = require("mongoose");

const numberRangeSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    object: {
      type: String, /// e.g. TRIP
      required: true,
    },
    rangeType: Number,
    withYear: Boolean,
    year: {
      type: Number, // autopicked?
    },
    start: {
      type: Number,
    },
    end: {
      type: Number,
    },
    runningNumber: {
      type: Number,
    },
    isGlobal: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("numberRange", numberRangeSchema);

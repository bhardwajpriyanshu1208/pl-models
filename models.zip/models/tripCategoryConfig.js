const mongoose = require("mongoose");

const tripCategorySchema = mongoose.Schema({
  company: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "company",
},
  tripCategory: {
    type: String,
    // required: true,
    // unique: true,
  },
  description: {
    type: String,
    // required: true,
  },
  isGlobal:{
    type : Boolean,
    default : false
  },
  createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    }},
    {
        timestamps: true,
      }
);

const TripCategory = mongoose.model("TripCategory", tripCategorySchema);

module.exports = TripCategory;
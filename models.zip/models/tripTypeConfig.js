const mongoose = require("mongoose");

const tripTypeSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    tripType: {
      type: String,
      // required: true,
      // unique: true,
    },
    description: {
      type: String,
      // required: true,
    },
    tripCategory: {
      type: String,
      // required: true,
    },
    modeOfTransport: {
      type: String,
    },
    numberRange: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "numberRange",
    },
    isGlobal: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

const TripType = mongoose.model("TripType", tripTypeSchema);

module.exports = TripType;

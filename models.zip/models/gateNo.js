const mongoose = require("mongoose");

const gateNoSchema = mongoose.Schema({
    company: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "company",
},
  gateNumber: {
    type: String,
    required: true,
    unique: true,
  },
  gateType: {
    type: String,
    required: true,
  },
  gateTypeDescription: {
    type: String,
    required: true,
  },
  plantSection: {
    type: String,
    required: true,
  },
  isGlobal:{
    type : Boolean,
    default : false
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
    required: true,
  }
}, {
  timestamps: true,
});


const GateNo = mongoose.model("GateNo", gateNoSchema);

module.exports = GateNo;
const mongoose = require('mongoose');

const stageSchema = new mongoose.Schema({
    stageId: {
        type: String,
        // type: mongoose.Schema.Types.ObjectId,
        // required: true
    },
    sourceLocId: {
        type: String,
        // type: mongoose.Schema.Types.ObjectId,
        // required: true
    },
    sourceDescription: {
        type: String,
        // required: true
    },
    sourceAddress: {
        type: String,
        // required: true
    },
    destinationId: {
        type: String,
        // type: mongoose.Schema.Types.ObjectId,
        // required: true
    },
    destinationDescription: {
        type: String,
        // required: true
    },
    destinationAddress: {
        type: String,
        // required: true
    },
    departureTime: {
        type: Date,
        // required: true
    },
    arrivalTime: {
        type: Date,
        // required: true
    },
    distance: {
        type: Number,
        // required: true
    },
    duration: {
        type: Number,
        // required: true
    },
    tripId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Trip",
      }
});

const Stage = mongoose.model("Stage", stageSchema);

module.exports = Stage;
const mongoose = require("mongoose");

const dockSchema = mongoose.Schema({
    company: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "company",
    },
    dockID: {
        type: String,
        required: true,
        unique: true,
    },
    dockType: {
        type: String,
        required: true,
    },
    dockTypeDescription: {
        type: String,
        required: true,
    },
    plantSection: {
        type: String,
        required: true,
    },
    isGlobal: {
        type: Boolean,
        default: false,
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user",
        required: true,
    }
}, {
    timestamps: true,
});

const Dock = mongoose.model("Dock", dockSchema);

module.exports = Dock;
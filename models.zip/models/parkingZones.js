const mongoose = require("mongoose");

const parkingZonesSchema = new mongoose.Schema(
  {
    location: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "location",
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    zoneId: {
      type: String,
      required: true,
    },
    vehicleType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "vehicleConfiguration",
    },
    description: String,
    capacity: Number,
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("parkingZone", parkingZonesSchema);

const mongoose = require("mongoose");

const businessPartnerSchema = mongoose.Schema(
  {
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    partnerId: {
      type: String,
    },

    name: {
      type: String,
    },

    partnerRole: {
      type: String,
    },

    contactPerson: {
      type: String,
    },

    contactNo: {
      type: String,
    },

    email: {
      type: String,
    },

    address: {
      street: String,
      houseNo: String,
      country: { type: String }, //required: true
      state: { type: String },
      city: { type: String },
      postalCode: {
        type: String,
      },
      timeZone: String,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

const BusinessPartner = mongoose.model(
  "businessPartner",
  businessPartnerSchema
);

module.exports = BusinessPartner;

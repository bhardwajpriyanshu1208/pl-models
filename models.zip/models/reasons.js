const mongoose = require("mongoose");
const reasonsSchema = new mongoose.Schema(
  {
    reasonCode: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    processID: {
      type: String,
      required: true,
      // enum: ["PL_VEH_REP", "PL_VEH_GP"],
    },
    isGlobal: {
      type: Boolean,
      default: false,
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("reason", reasonsSchema);
